
![Final](/setra_serial_data_logger_Final.png)

![Real Serial Data and Logging File](/Command_Center_AIO_RealData.jpg)

![alt text](/new_front_end_Python_Backend.jpg)


![More Cluster, More Resolution, More Better](/Inline_Cluster.png)

![Proof on Concept](/Version_once_POC_low_resolution.jpg)




-----------------

# 🌡️ Setra 225 Real‑Time Pressure Dashboard

A complete proof‑of‑concept for high‑resolution, **real‑time vacuum pressure monitoring**.

This system reads data from a **Setra Model 225** (4‑20 mA) industrial pressure sensor, digitizes the signal via Arduino (or RP2040 / ADS1115), sends it to a Python Flask backend, and visualizes it in a live web dashboard with **dynamic gauges, responsive charts, and logging**.

## ⚙️ Hardware Setup

Correct wiring is essential for this project to work. Your sensor is a **4-20mA current loop sensor**, which cannot be connected directly to the Arduino. You must use a **250-ohm precision resistor** to convert the current signal to a voltage signal.

**Components Needed:**
- **Microcontroller:** Arduino Uno / RP2040‑based board
- **Sensor:** Setra 225 (PN: 225G1R7BAC411), 0–1.7 Bar, 4–20 mA
- **Power Supply:** Suitable DC source (12 V or 24 V) for the sensor
- **Precision Sense Resistor:** 250 Ω (factory ref) or 499 Ω in‑test (1% or better)
- **Optional Resolution Upgrade:** ADS1115 16‑bit ADC
- **Jumper Wires & Breadboard**
- **Voltage Divider Resistors:** 10 kΩ + 10 kΩ for 2:1 scaling

**Wiring Diagram:**

```
+------------------+         +----------------------+       +----------------+
|                  |         |                      |       |                |
|  Sensor 12/24V   |-------->| Sensor V+ (Power)    |       |                |
|  Power Supply    |         |                      |       |                |
|      (-)         |--+----->| Sensor V- (Ground)   |       |  Arduino Uno   |
+------------------+  |      |                      |       |                |
                      |      |    Sensor Output (+) |---+-->| Pin A0         |
                      |      +----------------------+   |   |                |
                      |                                 |   |                |
                      +---------------------------------+-->| GND            |
                                                        |   +----------------+
                                                        |
                                                     +--+---+
                                                     |      |
                                                     R=250Ω <--Factory calibrated with but in the system is R=499Ω>
                                                     |      |
                                                     +--+---+
                                                        |
                                                        +-----> GND (Connected to Arduino and Power Supply Ground)
```

**Wiring Steps:**
1.  **Power the Sensor:** Connect the sensor's power input (`V+`) and ground (`V-`) to your DC power supply.
2.  **Create the Resistor Bridge:**
    *   Connect the sensor's **output wire** to one leg of the **250-ohm resistor**.
    *   Connect the other leg of the resistor to **Ground**.
3.  **Connect to Arduino:**
    *   Connect Arduino **Pin A0** to the point where the sensor output wire and the resistor meet.
    *   Connect an Arduino **GND** pin to the common ground of your circuit (the power supply ground and the low side of the resistor).

---

**Sensor current loop:**

* Connect sensor +24 V power from supply to (+) terminal of Setra 225 input.
* Connect Setra 225 output (current loop return) → one side of 499 Ω resistor.
* Other side of 499 Ω resistor = voltage signal.
* Voltage Divider

1. Signal from resistor → top of divider (R1 = 10 kΩ).
2. R1 bottom connected to R2 top (R2 = 10 kΩ).
3. R2 bottom → Ground.
4. ADS1115 AIN0 = junction of R1 & R2 (divided voltage).
5. ADS1115 GND to Arduino/RP2040 GND.
6. ADS1115 I²C connections

----------------------------------------------------------

1. VDD → 3.3 V or 5 V (match MCU logic level).
2. GND → MCU GND.
3. SDA → MCU SDA pin.
4. SCL → MCU SCL pin.
5. ADDR pin can be left floating for default I²C address (0x48).
6. Resistor ground = same ground as MCU & ADS1115.

**Advantages of RP2040 here:**

* Native 12‑bit ADC (better than most Arduinos) if using internal ADC directly.
* Much faster CPU for additional data processing/logging.
* Easily supports ADS1115 over I²C without speed bottleneck.
* Dual‑core allows real‑time acquisition & UI/communication in parallel.

```
### 📊 Wiring Block Diagram
  +24V Supply
       |
       v
+-------------------+
|   Setra 225       |
|  Pressure Sensor  |
|  (4–20 mA output) |
+-------------------+
       |
       v
  [ 499 Ω Sense Resistor ]
       |
       v
  Voltage: 2.0V (0 bar) → ~10.0V (1 bar)

       |
       v
+---------------------+
|  Voltage Divider    |  <-- e.g. R1 = 10kΩ, R2 = 10kΩ
|  (2:1 Scale)        |      reduces 0–10V → 0–5V
+---------------------+
       |
       v
+---------------------+
|  ADS1115 ADC        |
|  Gain = ±4.096 V    |
|  I²C SDA, SCL       |
+---------------------+
       |
       v
+----------------------+
|  Arduino / RP2040    |
|  (Read ADC, convert  |
|   to µbar)           |
+----------------------+

```

---

## 💻 Software Setup

### A. Upload Arduino Sketch
1.  Open the [`Setra225_Pressure_Sensor.ino`](Setra225_Pressure_Sensor.ino:1) file in the Arduino IDE.
2.  Connect your Arduino to your computer via USB.
3.  Select the correct board (`Arduino Uno`) and port (`COMx` or `/dev/tty...`) from the `Tools` menu.
4.  Click the "Upload" button.

### B. Install Python Libraries
1.  Open a terminal or command prompt.
2.  **(First-time setup)** It's good practice to ensure you have the latest packaging tools. Run this command first:
    ```bash
    python -m pip install --upgrade pip setuptools wheel
    ```
3.  Install the required Python packages for the project:
    ```bash
    pip install Flask Flask-SocketIO pyserial
    ```

---

---

## 🚀 Running the Dashboard

### A. Configure the Serial Port
1.  In the Arduino IDE (after uploading), check the `Tools > Port` menu to see which COM port your Arduino is using (e.g., `COM3`).
2.  Open the [`server.py`](server.py:1) file.
3.  On **line 9**, change the `SERIAL_PORT` variable to match the port you found.
    ```python
    # e.g., change "COM3" to your actual port
    SERIAL_PORT = "COM3"
    ```

### B. Start the Server
1.  In your terminal, navigate to the project directory.
2.  Run the Python server script in either **Live Mode** or **Simulation Mode**.

*   **Live Mode (Default)**
    *   Reads data from the connected Arduino.
    *   Run the script normally:
    ```bash
    python server.py
    ```

*   **Simulation Mode**
    *   Generates simulated vacuum data without needing an Arduino.
    *   Useful for testing the dashboard display.
    *   Run the script with the `--simulate` flag:
    ```bash
    python server.py --simulate
    ```
You should see output indicating that the server is running and attempting to connect to the serial port.

---

### 🌐 View the Dashboard
1.  Open your web browser.
2.  Navigate to the following address:
    [http://127.0.0.1:5000](http://127.0.0.1:5000)

You should now see the dashboard, and it will update in real-time!

💡 **Note:** The live chart and gauges use a **logarithmic scale** to span the full range from atmosphere down to ultra‑high vacuum, preserving detail in the low‑µbar region.


### D. Data Logging
The dashboard includes controls for logging data to a CSV file. This works in both Live and Simulation modes.
*   **Start Logging:** Click this button to begin saving data. A new file named `pressure_log_YYYYMMDD_HHMMSS.csv` will be created in the project directory. The status on the dashboard will update to show the active filename.
*   **Stop Logging:** Click this button to close the current CSV file.
*   You can start and stop logging as many times as you like; a new file will be created each time you click "Start Logging".